#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>
#include "create.h"
#include "update.h"
#include "search.h"
#include "sort.h"

void main()
{
	while (1) 
	{ //print out menu display
		char choice[100];
		printf("\n\t\t\t\t\tDonations and Distribution system.\n");
		printf("\n------------------------------------------------------------------------------------------------------------------------\n");

		printf("\nOptions: \n");

		printf("\n1.Create new donations file.\n");
		printf("\n2.Update quantity to Donations.\n");
		printf("\n3.Search quantity in Donations by donation code.\n");
		printf("\n4.List out total distribution of supplies.\n");
		printf("\n5.Exit");

		int choices;
		printf("\n\nEnter your Option: ");
		fgets(choice, 10, stdin);//get user input
		sscanf(choice, "%d", &choices);
		system("cls");//clear screen

		switch (choices)
		{
		case 1://create donation.txt file
			
			create();
			break;

		case 2://update donation.txt file

			update();
			break;

		case 3://search donation.txt with donation code

			search();
			break;
			

		case 4://bubble sort dist.txt by descending order and print out

			sort();
			printf("\nDistribution is listed.");
			break;

		case 5://exit 

			printf("Thank you.");
			exit(0);

		default://input not 1-5

			printf("Invalid input! Try again.\n");
			break;

		}
	}
}
#pragma once
#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define MAX_SIZE 256

// create the struct to store the text data into individual variables.
typedef struct DIST
{
    double qty;
    char supplycode[10];
};

void sort()
{
    int totallines = 0;
    struct DIST D[MAX_SIZE];
    struct DIST temp;
    int counter = 0;
    char line[300]; //line array to store the text data into

    FILE* fp;
    fp = fopen("dist.txt", "r");//open file to be read
    while (fgets(line, 100, fp)) //storing each line into the array
    {
        /** splitting values and strings and storing into struct variables*/
        sscanf(line, "%s %lf", &D[totallines].supplycode, &D[totallines].qty);
        totallines++;
    }


    for (counter = 0; counter < totallines - 1 ; counter++)
    {
        for (int newcounter = counter + 1 ; newcounter < totallines + 1 ; newcounter++)
        {
            if (D[counter].qty < D[newcounter].qty)
            {
                temp = D[counter];
                D[counter] = D[newcounter];
                D[newcounter] = temp;
            }
        }
    }
    printf("\nSORTED\n");
    puts("--------------------------------------------------------------------");
    puts("Supply Code  Quantity Distributed");
    puts("--------------------------------------------------------------------");
    for (counter = 0; counter < totallines; ++counter)
        printf("%-12s %g \n\n", D[counter].supplycode, D[counter].qty);


    double CTquantity = 0;
    double HSquantity = 0;
    double OMquantity = 0;
    double FMquantity = 0;
    double SMquantity = 0;

    for (counter = 0; counter < totallines; ++counter)
    {
        if (strcmp("CT", D[counter].supplycode) == 0)
        {
            CTquantity += D[counter].qty;
        }

        else if (strcmp("OM", D[counter].supplycode) == 0)
        {
            OMquantity += D[counter].qty;
        }
        else if (strcmp("HS", D[counter].supplycode) == 0)
        {
            HSquantity += D[counter].qty;
        }
        else if (strcmp("FM", D[counter].supplycode) == 0)
        {
            FMquantity += D[counter].qty;
        }
        else if (strcmp("SM", D[counter].supplycode) == 0)
        {
            SMquantity += D[counter].qty;
        }
    }
    puts("--------------------------------------------------------------------");
    puts("Total of each supply Distributed");
    puts("--------------------------------------------------------------------");
    printf("\nTotal CT quantity distributed: %g\n", CTquantity);
    puts("--------------------------------------------------------------------");
    printf("\nTotal HS quantity distributed: %g\n", HSquantity);
    puts("--------------------------------------------------------------------");
    printf("\nTotal FM quantity distributed: %g\n", FMquantity);
    puts("--------------------------------------------------------------------");
    printf("\nTotal SM quantity distributed: %g\n", SMquantity);
    puts("--------------------------------------------------------------------");
    printf("\nTotal OM quantity distributed: %g\n", OMquantity);
    puts("--------------------------------------------------------------------");

}
#pragma once
#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>
#include <string.h>


// create the struct to store the text data into individual variables.
struct SEARCH
{
    char donationcode[10];
    char supplyname[50];
    char supplycode[10];
    char donator[50];
    int shipment;
    double qty;
};

//main program
int search()
{
    struct SEARCH S[5];// create an array of struct with 6 spaces.
    int i = 0;
    int j = 0;
    int k;
    char d;
    char donationcode[10];
    char line[300]; //line array to store the text data into
    FILE* fp;
    fp = fopen("donation.txt", "r");//open file to be read

    while (fgets(line, 100, fp)) //storing each line into the array
    {
        /** splitting values and strings and storing into struct variables*/
        sscanf(line, "%s %[^\t] %s %[^\t] %d %lf", S[j].donationcode, &S[j].supplyname, &S[j].supplycode, &S[j].donator, &S[j].shipment, &S[j].qty);
        j++;
    }
    fclose(fp);
    printf("\nEnter Donation code to search: ");
    fgets(donationcode, 10, stdin);
    sscanf(donationcode,"%s",&donationcode);//read and store user input supply code into var

    for (i = 0; i < j; i++)
    {
        if (strcmp(donationcode, S[i].donationcode) == 0)
        {
            printf("\nFound: ");
            printf("\n------------------------------------------------------------------------------------------------------------------------\n");
            printf("%s", "\nDonation Code\tSupply Name  \t\t Supply Code\t Donator\t No. of shipment\t Quantity of boxes(Mil)\n");
            printf("\n------------------------------------------------------------------------------------------------------------------------\n");
            printf("\n%-16s%-25s%-16s%-16s%-24d%.2lf\n", S[i].donationcode, S[i].supplyname, S[i].supplycode, S[i].donator, S[i].shipment, S[i].qty);
            printf("\n-------------------------------------------------------------------------------------------------------------------------\n");
            break;
        }
    }
    if ( i >= j)
    {
        printf("\nInvalid Input\n");
        puts("\nTry Again.\n");
        search();
    }

    //closing all open files
    return 0;
}

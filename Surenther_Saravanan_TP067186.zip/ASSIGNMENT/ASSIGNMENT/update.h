#pragma once
#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>
#include <string.h>


// create the struct to store the text data into individual variables.
struct SUPPLIES 
{
    char donationcode[10];
    char supplyname[50];
    char supplycode[10];
    char donator[50];
    int shipment;
    double qty;
};

//main program
int update()
{
    struct SUPPLIES S[5];// create an array of struct with 6 spaces.
    int i = 0;
    int j = 0;
    char line[300]; //line array to store the text data into
    char newsupcode[10];//user inputed supply code 
    int value;
    int k = 0;
    char newshp[10];
    int newshipmentno = 0;
    double newquantity;//user inputed quantity to be added to the supply item
    FILE* fp;
    
    fp = fopen("donation.txt", "r");//open file to be read
    
    while (fgets(line, 100, fp)) //storing each line into the array
    {
        /** splitting values and strings and storing into struct variables*/
        sscanf(line, "%s %[^\t] %s %[^\t] %d %lf",S[j].donationcode ,&S[j].supplyname, &S[j].supplycode, &S[j].donator, &S[j].shipment, &S[j].qty);
        j++;
    }
    fclose(fp);

    printf("\nData in file currently: \n\n");
    //print out text file contents
    printf("------------------------------------------------------------------------------------------------------------------------\n");
    printf("%s","\nDonation Code\tSupply Name  \t\t Supply Code\t Donator\t No. of shipment\t Quantity of boxes(Mil)\n");
    printf("\n------------------------------------------------------------------------------------------------------------------------\n");
    for (i = 0; i < j; ++i)
        printf("\n%-16s%-25s%-16s%-16s%-24d%.2lf\n", S[i].donationcode, S[i].supplyname, S[i].supplycode, S[i].donator, S[i].shipment, S[i].qty);
    
    printf("\n------------------------------------------------------------------------------------------------------------------------\n");


    while (1) 
    {
        printf("\nEnter Supply code: ");
        fgets(newsupcode, 10, stdin);
        sscanf(newsupcode,"%s", &newsupcode);

        char newqty[10];
        printf("\nEnter quantity amount to be changed: ");
        fgets(newqty, 10, stdin);
        sscanf(newqty ,"%lf", &newquantity);

        printf("\nChoose '1' to add or '2' to distribute '3' to exit the function: ");
        char pick[10];
        fgets(pick,10,stdin);
        int picks;
        sscanf(pick, "%d", &picks);

        switch (picks) 
        {
        case 1://add function
           
            printf("\nEnter Number of Shipments coming in: ");
            fgets(newshp, 10, stdin);
            sscanf(newshp,"%d", &newshipmentno);

            for (k = 0; k < 6; k++)
            {
                
                int c = strcmp(S[k].supplycode, newsupcode);//comparing the strings
                if (c == 0)
                    //if both strings are the same
                {
                    S[k].qty += newquantity;
                    S[k].shipment += newshipmentno;
                    printf("\nNew quantity balance of %s is : %.2lf\n", newsupcode, S[k].qty);
                    break;
                }

            }
            if (k >= 6)
            {
                printf("\nInvalid Input.\n");
                printf("\nTry again\n");
                break;
            }
            printf("\n-----------------------------------------------------------------------------------------------------------------\n");

            printf("\nFile updated. Contents are: \n");//print out updated contents of the text tile
   
            printf("------------------------------------------------------------------------------------------------------------------------\n");
            printf("%s", "\nDonation Code\tSupply Name  \t\t Supply Code\t Donator\t No. of shipment\t Quantity of boxes(Mil)\n");
            printf("\n------------------------------------------------------------------------------------------------------------------------\n");
           
            for (i = 0; i < j; ++i)
                printf("\n%-16s%-25s%-16s%-16s%-24d%.2lf\n", S[i].donationcode, S[i].supplyname, S[i].supplycode, S[i].donator, S[i].shipment, S[i].qty);

            printf("\n------------------------------------------------------------------------------------------------------------------------\n");
            

            fp = fopen("donation.txt", "w+");//write the new values into the text file
            for (i = 0; i < j; ++i)
                fprintf(fp, "%s %-25s\t%-16s%-16s\t%-24d%.2lf\n", S[i].donationcode, S[i].supplyname, S[i].supplycode, S[i].donator, S[i].shipment, S[i].qty);
            fclose(fp);
            puts("\nAdded successfully.\n");
            return 0;

        case 2://distribute function

            for (k = 0; k < 6; k++)
            {
                int c = strcmp(S[k].supplycode, newsupcode);//comparing the strings
                if (c == 0)
                    //if both strings are the same
                {
                    S[k].qty -= newquantity;
                    printf("New quantity balance of %s is : %.2lf\n", newsupcode, S[k].qty);
                    break;
                }

            }
            if (k >= 6) 
            {
                printf("\nInvalid input\n");
                printf("\nTry Again.\n");
                break;
            }
            printf("\n----------------------------------------------------------------------------------------------------------------------\n");

            printf("\nFile updated. Contents are: \n");//print out updated contents of the text tile

            printf("------------------------------------------------------------------------------------------------------------------------\n");
            printf("%s", "\nDonation Code\tSupply Name  \t\t Supply Code\t Donator\t No. of shipment\t Quantity of boxes(Mil)\n");
            printf("\n------------------------------------------------------------------------------------------------------------------------\n");
            
            for (i = 0; i < j; ++i)
                printf("\n%-16s%-25s%-16s%-16s%-24d%.2lf\n", S[i].donationcode, S[i].supplyname, S[i].supplycode, S[i].donator, S[i].shipment, S[i].qty);

            printf("\n------------------------------------------------------------------------------------------------------------------------\n");

            fp = fopen("donation.txt", "w");//write the new values into the text file
            for (i = 0; i < j; ++i)
                fprintf(fp, "%s %-25s\t%-16s%-16s\t%-24d%.2lf\n", S[i].donationcode, S[i].supplyname, S[i].supplycode, S[i].donator, S[i].shipment, S[i].qty);
            fclose(fp);

            fp = fopen("dist.txt", "a+");//append the supply code and quantity distributed into the text file.
            fprintf(fp, "%s %.2lf \n", newsupcode, newquantity);
            fclose(fp);// closing dist files.
            printf("\nDistributed Successfully.\n");
            return 0;

        case 3:
            return 0;

        default://if input is not 1-3
            printf("Invalid input. Try Again.\n");
            return 0;
        }
    
    }
    

}
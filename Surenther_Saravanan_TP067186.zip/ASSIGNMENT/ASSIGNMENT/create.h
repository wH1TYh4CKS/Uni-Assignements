#pragma once
#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <string.h>

int create()
{
	char donationcode[10];
	char supplyname[50];
	char supplycode[10];
	char donator[50];
	char shp[10];
	char qty[10];
	int i, shipment;
	double quantity;

	FILE* fp;
	fp = fopen("donation.txt", "r");

	if (!fp)//if file doesnt exist
	{
		fp = fopen("donation.txt", "w");//create the text file to be written into
		fclose(fp);//close the file
	}

	printf("Create Donations File.");
	printf("\n------------------------------------------------------------------------------------------------------------------------\n");
	for (i = 0; i < 5; i++)//loop 5 times for 5 items and 1 item per line into text file
	{//taking user inputs


		printf("\nEnter Donation Code: ");
		fgets(donationcode, 10, stdin);
		sscanf(donationcode, "%s", &donationcode);
		printf("Enter Supply Name:");
		fgets(supplyname, 50,stdin);
		sscanf(supplyname,"%[^\n]s", &supplyname);
		printf("Enter Supply Code: ");
		fgets(supplycode, 10,stdin);
		sscanf(supplycode, "%[^\n]s", &supplycode);
		printf("Enter Donator Name: ");
		fgets(donator, 50,stdin);
		sscanf(donator, "%[^\n]s", &donator);
		printf("Enter No. Of Shipment: ");
		fgets(shp, 10, stdin);
		sscanf(shp ,"%d", &shipment);
		printf("Enter Quantity of boxes donated: ");
		fgets(qty, 10, stdin);
		sscanf(qty,"%lf", &quantity);


		fp = fopen("donation.txt", "a+");//opening text file to add user inputed data

		printf("\nData entered.\n");
		printf("\n------------------------------------------------------------------------------------------------------------------------\n");
		printf("\n%-13s%-25s%-16s%-16s%-24d%.2lf\n",donationcode ,supplyname, supplycode, donator, shipment, quantity);
		printf("\n------------------------------------------------------------------------------------------------------------------------\n");
		fprintf(fp,"%s %-25s\t%-16s%-16s\t%-24d%.2lf\n",donationcode,supplyname, supplycode, donator, shipment, quantity);//storing the data into text file
		
		fclose(fp);//close file after looped 5 times

	}

	printf("\nData added successfully.");
}